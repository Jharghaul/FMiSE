//import java.util.Arrays;


public class DuplicateFreeArray {

	//@ public invariant (\forall int i;(\forall int j; i>=0 && i<j && j<content.length; content[i] != content[j]));
	private /*@ spec_public @*/ int[] content;
	
	
	public DuplicateFreeArray(int[] is) {
		this.content = is;
	}

	/*@ public normal_behavior
	  @ requires length >= 0 && content.length >= length;
	  @ requires at >= 0 && target.length >= at + length;
	  @ requires target != content; 
	  @ assignable target[at..at+length-1];
	  @ ensures (\forall int j; j>=0 && j<length; target[at + j] == content[j]);
	  @*/
	public void copyInto(int[] target, int at, int length) {
		/*@ loop_invariant i>=0 && i<=length && (\forall int j; j>=0 && j<i; target[at + j] == content[j]);
		  @ assignable target[at..at+length-1];
		  @ decreases length - i; 
		  @*/
		for (int i = 0; i<length; i++) {
			target[at + i] = content[i];
		}
	}
	
	
	/*@ public normal_behavior
	  @ requires content.length >= 1;
	  @ ensures \result == content[content.length - 1];
	  @*/
	public int last() {
		return content[content.length - 1];
	}
	
}
