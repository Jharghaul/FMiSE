public class IllegalHeartRateException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private /*@ spec_public @*/ int rate;

	public IllegalHeartRateException(int rate) {
		this.rate = rate;
	}

	public String getMessage() {
		return "Rate " + rate + " is not a valid heartrate.";
	}

}
