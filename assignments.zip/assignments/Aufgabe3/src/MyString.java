public class MyString {
	
	private /*@ spec_public @*/ char[] content;

      /*@ public normal_behaviour
	@ requires content.length >= 1 && content != null; 
	@ assignable content[*];
	@ ensures content.length == \old(content).length;
	@ ensures (\forall int i; i<content.length && i>=0; (\old(content)[i] == o || content[i]==\old(content)[i]) && (\old(content)[i] != o || content[i]==n));
	@ diverges true;
	@*/	
	public void replace(char o, char n){
		if(content == null) return;
		int i = 0;
		/*@ loop_invariant i<=content.length && i>=0 && (\forall int j; j<i && j>=0; (\old(content)[j] == o || content[j] == \old(content)[j]) && (\old(content)[j] != o || content[j] == n));
		  @ decreases content.length-i;
		  @ assignable content[*];
		  @*/
		while (i<content.length) {
			if (content[i] == o) {
				content[i] = n;
			}
			i++;
		}				
	}
}
