public class HeartRate {
	
	private /*@ spec_public @*/ static int INITIAL_CAPACITY = 30;
	
	// public invariant (\forall int i; i>=0 && i<heartRate.length; heartRate[i]>=0) && (\forall int i; i>=size && i<heartRate.length; heartRate[i]==0);
	private /*@ spec_public @*/ int[] heartRate;

	// public invariant (size<=heartRate.length && size>=0);
	private /*@ spec_public @*/ int size;
	
	// public invariant (alertRate>=80);
	private /*@ spec_public @*/ int alertRate;	
	
	
	public HeartRate(int alertRate) {
		this.heartRate = new int[INITIAL_CAPACITY];
		this.alertRate = alertRate;
		this.size = 0;
	}

	
	/*@ public normal_behaviour
	  @ requires rate>=0;
	  @ requires size<heartRate.length && size>=0;
	  @ assignable heartRate[size],size;
	  @ ensures heartRate[size-1]==rate && \old(size) == size-1;
	  @ diverges true;
	  @
	  @ also
	  @
	  @ public normal_behaviour
	  @ requires size==heartRate.length && rate>=0 && heartRate.length>0;
	  @ assignable heartRate,size;
	  @ ensures (heartRate.length==\old(heartRate).length*2); 
	  @ ensures (\forall int i; i>=0 && i<\old(heartRate).length; heartRate[i]==\old(heartRate)[i]);
	  @ ensures size == \old(size)+1;
	  @ ensures heartRate[size-1]==rate;
	  @ diverges true;
	  @	
	  @ also
	  @
	  @ public exceptional_behaviour
	  @ requires rate<0;
	  @ signals_only IllegalHeartRateException;
	  @ assignable \nothing;
	  @*/
	public void add(int rate) throws IllegalHeartRateException{
		// just for testing
		
		if(rate < 0) throw new IllegalHeartRateException(rate);
		if(size < 0 || heartRate.length <= 0) return;
		if(size<heartRate.length){
			heartRate[size] = rate;
			size = size+1;
		}
		else{
			int[] tmp = new int[heartRate.length*2];
			/*@ loop_invariant i>=0 && i<= heartRate.length && tmp!=heartRate && heartRate.length*2 == tmp.length && (\forall int j; j>=0 && j<i; tmp[j]==heartRate[j]);
			  @ decreases heartRate.length - i;
			  @ assignable \nothing;
			  @*/
			for(int i=0; i<heartRate.length; i++){ tmp[i] = heartRate[i];}
			heartRate = tmp;
			heartRate[size] = rate;
			size = size+1;
		}
		
	}
	
    	/*@ public normal_behaviour
	  @ requires size>=3 && heartRate.length >= size;
	  @ assignable \nothing;
	  @ ensures \result==(\exists int i; i>=0 && i<=size-3; (heartRate[i]+heartRate[i+1]+heartRate[i+2])/3>=alertRate);
	  @ diverges true;
	  @
	  @ also
	  @
	  @ public normal_behavior
	  @ requires size<3 || heartRate.length < 3;
	  @ assignable \nothing;
	  @ ensures \result==false;
	  @ diverges true;
	  @*/
	public boolean alert(){
		// just for testing
		
		if(size<3 || heartRate.length < 3) return false;
		/*@ loop_invariant i<=size-2 && i>=0 && (\forall int j; j >= 0 && j < i ; (heartRate[j]+heartRate[j+1]+heartRate[j+2])/3 < alertRate);
		  @ decreases size-2-i;
		  @ assignable \nothing;
		  @*/
		for(int i=0; i<=size-3; i++)
			if((heartRate[i]+heartRate[i+1]+heartRate[i+2])/3 >= alertRate) return true;
		return false;
		
	}
}
